# -*- coding: utf-8 -*-

from .views import tasks
from .models import MyTaskModel, MyTaskModelAdmin
from .forms import MyTaskForm